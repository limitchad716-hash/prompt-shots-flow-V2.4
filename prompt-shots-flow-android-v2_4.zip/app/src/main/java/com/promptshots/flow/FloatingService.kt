package com.promptshots.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.exp

/** Glyphs for the option tiles (plain symbols, so they render the same on every phone). */
private object G {
    const val PLAY = "\u25B6"
    const val PLAY_ALL = "\u25B6\u25B6"
    const val STOP = "\u25A0"
    const val PAUSE = "\u275A\u275A"
    const val BACK = "\u2039"
    const val SKIP = "\u203A"
    const val RESTART = "\u21BA"
    const val PASTE = "\u2193"
    const val CLEAR = "\u00D7"
    const val LOOP = "\u21BB"
    const val RANDOM = "\u2248"
    const val GLOW = "\u2726"
    const val HIDE = "\u25BE"
    const val BELL = "\u266A"
    const val HELP = "?"
    const val REC = "\u25CF"
    const val TOUCH = "\u25CE"
    const val CLOSE = "\u2715"
    const val MINUS = "\u2212"
    const val PLUS = "+"
}

class FloatingService : Service() {
    companion object {
        /** True while the bubble exists; MainActivity uses it to label the Float button. */
        @Volatile var alive = false
        private const val ACTION_STOP = "com.promptshots.flow.STOP"
        private const val BUBBLE_DP = 92 // view size, includes room for the glow
        private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        private const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
        /** Steps for the paste-interval buttons (custom values 5..3600 s can be typed in Settings). */
        val DELAY_PRESETS = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 300, 600)

        /** One prompt per line; or, if there are blank lines, one prompt per paragraph. */
        fun parsePrompts(text: String): List<String> {
            val t = text.replace("\r\n", "\n")
            val parts = if (t.contains("\n\n")) {
                t.split(Regex("\n\\s*\n")).map { block -> block.lines().joinToString(" ") { it.trim() }.trim() }
            } else {
                t.lines().map { it.trim() }
            }
            return parts.filter { it.isNotEmpty() }
        }
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())  // Run all loop
    private val ui = Handler(Looper.getMainLooper()) // panel animation + generation watcher

    // Bubble
    private var bubble: GlowBubble? = null
    private var bubbleLp: WindowManager.LayoutParams? = null

    // Panel. [panel] stays set until the window is really removed, so a second window can never be added.
    private var panel: View? = null
    private var panelOpen = false
    private var panelBusy = false // true while it pops in / out; taps on the bubble are ignored meanwhile
    private var panelBorder: RainbowBorder? = null
    private var edit: EditText? = null
    private var info: TextView? = null
    private var modeBadge: TextView? = null
    private var tipView: TextView? = null
    private var genBar: GenBar? = null
    private var genLabel: TextView? = null
    private var genPctView: TextView? = null
    private var intervalValue: TextView? = null
    private var runAllBtn: Pill? = null
    private var pauseTile: Tile? = null
    private var recTile: Tile? = null
    private var fpsTile: Tile? = null
    private val segs = arrayOfNulls<Pill>(4)

    private var shownKind = PromptKind.IMAGE
    private var selected = 0 // 0 = Auto, 1 = Image, 2 = Video, 3 = ChatGPT
    private val idxByKind = intArrayOf(0, 0, 0)
    private var detected: FlowScreen? = null
    private var helpPinned = false
    private var paused = false
    private var index = 0
    private var running = false
    private var remaining = 0
    private var sending = false // a paste is in flight; ignore extra taps

    // Generation progress (0..100 %) read from Flow's tiles
    private var genArmed = false
    private var genSeen = false
    private var genMissing = 0
    private var genStart = 0L
    private var genChat = false
    private var curPct = 0
    private var curGenText = "Idle"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        alive = true
        RecordService.onChange = { h.post { if (alive) refresh() } }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            addBubble()
        }
        // Not sticky: on Android 12+ the system can't restart a foreground service from the background.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        RecordService.onChange = null
        running = false
        genArmed = false
        h.removeCallbacksAndMessages(null)
        ui.removeCallbacksAndMessages(null)
        panelBorder?.stop()
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        panel = null; bubble = null
        super.onDestroy()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("flow", "Floating window", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "flow") else Notification.Builder(this)
        val n = b.setContentTitle("FLOW floating window is on")
            .setContentText("Tap to open Prompt Shots")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Close", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ── Bubble ─────────────────────────────────────────────────────────────

    private fun addBubble() {
        val t = GlowBubble(this).apply { glow = Prefs.flag(this@FloatingService, "glow", true) }
        val size = dp(BUBBLE_DP)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0; lp.y = dp(140)
        t.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            lp.x = (sx + dx).coerceIn(0, maxOf(0, dm.widthPixels - size))
                            lp.y = (sy + dy).coerceIn(0, maxOf(0, dm.heightPixels - size))
                            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                            positionPanel()
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        v.animate().cancel()
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).withEndAction {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
                        }.start()
                        togglePanel()
                    } else {
                        // Snap to the nearest screen edge so the bubble stays out of the way.
                        lp.x = if (lp.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                        positionPanel()
                    }
                }
                return true
            }
        })
        wm.addView(t, lp)
        bubble = t; bubbleLp = lp
    }

    /** Idle: the F logo. Running: seconds until the next prompt, in green. */
    private fun updateBubble() {
        val b = bubble ?: return
        b.label = when {
            !running -> if (RecordService.recording) "REC" else ""
            paused -> "II"
            remaining > 0 -> "$remaining"
            else -> "…"
        }
        b.textSp = if (running) 17f else 12f
        b.animated = !running
        b.textColor = if (running) Ui.OK else Ui.BAD
        b.fill = when {
            running -> Ui.OK_BG
            RecordService.recording -> Ui.BAD_BG
            else -> 0xFF0B0D14.toInt()
        }
    }

    // ── Panel window ───────────────────────────────────────────────────────

    private fun panelWidth() = minOf(dp(344), resources.displayMetrics.widthPixels - dp(8))

    /** Keeps the panel next to the bubble and fully on screen (above it if there's no room below). */
    private fun positionPanel() {
        val p = panel ?: return
        val bl = bubbleLp ?: return
        val lp = p.layoutParams as? WindowManager.LayoutParams ?: return
        val dm = resources.displayMetrics
        lp.x = (bl.x - dp(8)).coerceIn(0, maxOf(0, dm.widthPixels - lp.width))
        val below = bl.y + dp(BUBBLE_DP - 22)
        val ph = if (p.height > 0) p.height else dp(520)
        lp.y = if (below + ph > dm.heightPixels - dp(16)) maxOf(0, bl.y + dp(22) - ph) else below
        try { wm.updateViewLayout(p, lp) } catch (_: Exception) {}
    }

    /** One entry point for the bubble tap and the – button. Ignored while a pop animation runs. */
    private fun togglePanel() {
        if (panelBusy) return
        if (panelOpen) hidePanel() else showPanel()
    }

    private fun clearPanelRefs() {
        edit = null; info = null; modeBadge = null; tipView = null; genBar = null; genLabel = null
        genPctView = null; intervalValue = null; runAllBtn = null; pauseTile = null; recTile = null
        fpsTile = null
        for (i in segs.indices) segs[i] = null
    }

    private fun hidePanel() {
        val old = panel ?: return
        panelBusy = true
        panelOpen = false
        saveCurrentPrompts()
        idxByKind[shownKind.ordinal] = index
        clearPanelRefs()
        val border = panelBorder
        panelBorder = null
        var removed = false
        fun remove() {
            if (removed) return
            removed = true
            border?.stop()
            try { wm.removeView(old) } catch (_: Exception) {}
            if (panel === old) panel = null
            panelBusy = false
        }
        old.animate().cancel()
        old.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { remove() }.start()
        ui.postDelayed({ remove() }, 260) // safety net in case the animation is cancelled
    }

    private fun showPanel() {
        if (panel != null) return // a window already exists; never add a second one
        panelBusy = true
        panelOpen = true
        val p = buildPanel()
        val lp = WindowManager.LayoutParams(
            panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        lp.x = bubbleLp?.x ?: 0; lp.y = (bubbleLp?.y ?: dp(140)) + dp(BUBBLE_DP - 22)
        p.alpha = 0f // hidden until positioned, then it pops in
        try { wm.addView(p, lp) } catch (_: Exception) { panelBusy = false; panelOpen = false; clearPanelRefs(); return }
        panel = p
        panelBorder?.start()
        refresh()
        applyAuto()
        p.post {
            if (panel !== p) return@post
            positionPanel()
            // Grow out of the bubble: pivot near the bubble, on the side the panel opened.
            val bl = bubbleLp
            val wl = p.layoutParams as? WindowManager.LayoutParams
            if (bl != null && wl != null) {
                p.pivotX = (bl.x + dp(BUBBLE_DP) / 2 - wl.x).toFloat().coerceIn(0f, p.width.toFloat())
                p.pivotY = if (wl.y >= bl.y) 0f else p.height.toFloat()
            }
            p.scaleX = 0.88f; p.scaleY = 0.88f
            p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .withEndAction { panelBusy = false }.start()
        }
        ui.postDelayed({ panelBusy = false }, 400) // safety net
        ui.postDelayed(detectTick, 1500)
    }

    private val detectTick = object : Runnable {
        override fun run() {
            if (!panelOpen) return
            applyAuto()
            ui.postDelayed(this, 1500)
        }
    }

    // ── Hold-to-explain ────────────────────────────────────────────────────

    private fun showTip(text: String) {
        tipView?.let { it.text = text; it.visibility = View.VISIBLE }
        panel?.post { positionPanel() }
    }

    private fun hideTip() {
        if (helpPinned) return
        tipView?.visibility = View.GONE
        panel?.post { positionPanel() }
    }

    /** Hold a view to show [tip]; it disappears on release. */
    private fun holdTip(v: View, tip: () -> String) {
        v.setOnLongClickListener { showTip(tip()); true }
        when (v) {
            is Tile -> v.onRelease = { hideTip() }
            is Pill -> v.onRelease = { hideTip() }
        }
    }

    // ── Image / Video / Auto ───────────────────────────────────────────────

    private fun kindIcon(k: PromptKind) = when (k) { PromptKind.VIDEO -> "🎬"; PromptKind.CHATGPT -> "💬"; else -> "🖼" }
    private fun kindName(k: PromptKind) = when (k) { PromptKind.VIDEO -> "Video"; PromptKind.CHATGPT -> "ChatGPT"; else -> "Image" }
    private fun hintFor(k: PromptKind) =
        "${kindName(k)} prompts: isa kada linya\n(o paghiwalayin ng blank line)"

    private fun saveCurrentPrompts() {
        edit?.let { Prefs.setPrompts(this, it.text?.toString() ?: "", shownKind) }
    }

    /** Shows the other prompt list in the box; each kind keeps its own prompts and position. */
    private fun switchKind(k: PromptKind) {
        if (k == shownKind) return
        saveCurrentPrompts()
        idxByKind[shownKind.ordinal] = index
        shownKind = k
        index = idxByKind[k.ordinal]
        edit?.let { it.hint = hintFor(k); it.setText(Prefs.prompts(this, k)) }
        refresh()
    }

    private fun styleSegs() {
        for (i in 0..3) segs[i]?.setKind(if (selected == i) Ui.Kind.PRIMARY else Ui.Kind.SECONDARY)
    }

    private fun selectMode(m: Int) {
        if (running) { toast("Itigil muna ang Run all bago magpalit"); return }
        selected = m
        styleSegs()
        when (m) {
            1 -> switchKind(PromptKind.IMAGE)
            2 -> switchKind(PromptKind.VIDEO)
            3 -> switchKind(PromptKind.CHATGPT)
            else -> applyAuto()
        }
        updateBadge()
    }

    /** Reads the Flow screen; in Auto mode, switches to the matching prompt list. */
    private fun applyAuto() {
        val svc = FlowAccessibilityService.instance
        detected = svc?.detectScreen()
        val k = detected?.kind
        if (selected == 0 && k != null && !running) switchKind(k)
        updateBadge()
    }

    private fun updateBadge() {
        val k = detected?.kind
        val model = detected?.model
        modeBadge?.text = when {
            FlowAccessibilityService.instance == null -> "Auto-detect: i-on ang Accessibility sa Setup"
            k == null -> "Hindi pa mabasa ang Flow. Buksan ang Google Flow."
            else -> "Nakita: ${kindIcon(k)} ${kindName(k)}" + (if (model != null) "  ·  $model" else "")
        }
    }

    // ── Panel building ─────────────────────────────────────────────────────

    private fun lp(w: Int, hh: Int) = LinearLayout.LayoutParams(w, hh)
    private fun lpw(hh: Int, weight: Float = 1f) = LinearLayout.LayoutParams(0, hh, weight)

    private fun onOff(b: Boolean) = if (b) " (Naka-on)" else " (Naka-off)"
    private fun flag(k: String, def: Boolean) = Prefs.flag(this, k, def)

    private fun section(name: String) = TextView(this).apply {
        text = name; setTextColor(Ui.MUTED); textSize = 9f; typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.14f
        setPadding(dp(3), dp(10), 0, dp(4))
    }

    /** A labelled option tile. Tap = do it. Hold = explain it. */
    private fun tile(glyph: String, label: String, tip: () -> String, danger: Boolean = false, onTap: (Tile) -> Unit): Tile {
        val t = Tile(this, glyph, label, onTap)
        t.danger = danger
        holdTip(t, tip)
        return t
    }

    private fun tileRow(vararg v: View): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        v.forEach {
            val l = lpw(dp(56))
            l.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(it, l)
        }
        return r
    }

    private fun buildPanel(): LinearLayout {
        val glowPad = dp(16)
        val inner = dp(10)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val rb = RainbowBorder(dp(22).toFloat(), dp(2).toFloat(), 0xF507080D.toInt(), glowPad.toFloat())
            rb.glowOn = Prefs.flag(this@FloatingService, "glow", true)
            panelBorder = rb
            background = rb
            setPadding(glowPad + inner, glowPad + inner, glowPad + inner, glowPad + inner)
        }

        // Header: logo, title, minimise
        val logo = LogoView(this)
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@FloatingService).apply {
                text = "FLOW"; typeface = Typeface.DEFAULT_BOLD; setTextColor(Ui.ACCENT)
                textSize = 15f; letterSpacing = 0.18f
            })
            addView(TextView(this@FloatingService).apply {
                text = "Paste & Run  ·  Prompt Shots"; setTextColor(Ui.MUTED); textSize = 10f
            })
        }
        val minimize = Pill(this, G.HIDE, Ui.Kind.SECONDARY) { togglePanel() }.apply {
            setPadding(0, 0, 0, 0); textSize = 16f
        }
        holdTip(minimize) { "Itago ang panel. Nandito pa rin ang bubble." }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(logo, lp(dp(38), dp(38)))
        head.addView(titleCol, lpw(WRAP).apply { marginStart = dp(6) })
        head.addView(minimize, lp(dp(40), dp(34)))
        root.addView(head)

        // Explanation box (outside the scroll area so it is always visible)
        val tip = TextView(this).apply {
            setTextColor(Ui.TEXT); textSize = 12f
            background = Ui.stroked(Ui.SURFACE, Ui.ACCENT, dp(10).toFloat(), dp(1))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = View.GONE
        }
        tipView = tip
        helpPinned = false
        root.addView(tip, lp(MATCH, WRAP).apply { topMargin = dp(6) })

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Mode: Auto / Image / Video
        val segAuto = Pill(this, "✨ Auto", Ui.Kind.SECONDARY) { selectMode(0) }
        val segImg = Pill(this, "🖼 Image", Ui.Kind.SECONDARY) { selectMode(1) }
        val segVid = Pill(this, "🎬 Video", Ui.Kind.SECONDARY) { selectMode(2) }
        val segGpt = Pill(this, "💬 GPT", Ui.Kind.SECONDARY) { selectMode(3) }
        segs[0] = segAuto; segs[1] = segImg; segs[2] = segVid; segs[3] = segGpt
        segs.forEach { it?.apply { textSize = 11.5f; setPadding(dp(4), dp(10), dp(4), dp(10)) } }
        holdTip(segGpt) { "Para sa ChatGPT (app o browser). Hiwalay ang listahan. Hihintayin munang matapos ang sagot bago ang susunod na prompt." }
        holdTip(segAuto) { "Awtomatikong binabasa ang Flow screen at pinipili ang Image o Video prompts ayon sa nakikita." }
        holdTip(segImg) { "Listahan ng prompts para sa larawan. Hiwalay ito sa Video." }
        holdTip(segVid) { "Listahan ng prompts para sa video. Hiwalay ito sa Image." }
        styleSegs()
        val badge = TextView(this).apply { setTextColor(Ui.MUTED); textSize = 11f; setPadding(dp(3), dp(2), dp(3), dp(2)) }
        modeBadge = badge
        updateBadge()
        col.addView(Ui.row(this, segAuto, segImg, segVid, segGpt), lp(MATCH, WRAP).apply { topMargin = dp(8) })
        col.addView(badge)

        // Prompt box
        val e = EditText(this).apply {
            hint = hintFor(shownKind)
            setHintTextColor(Ui.MUTED); setTextColor(Ui.TEXT); textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3; maxLines = 4; gravity = Gravity.TOP
            background = Ui.stroked(Ui.SURFACE, Ui.LINE, dp(12).toFloat(), dp(1))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setText(Prefs.prompts(this@FloatingService, shownKind))
            // Let the box scroll its own text instead of the whole panel.
            setOnTouchListener { v, ev ->
                v.parent?.requestDisallowInterceptTouchEvent(ev.actionMasked != MotionEvent.ACTION_UP && ev.actionMasked != MotionEvent.ACTION_CANCEL)
                false
            }
        }
        edit = e
        val i = TextView(this).apply { setTextColor(Ui.MUTED); textSize = 12f; setPadding(dp(3), dp(6), dp(3), dp(2)) }
        info = i
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.setPrompts(this@FloatingService, s?.toString() ?: "", shownKind)
                refresh()
            }
        })
        col.addView(e, lp(MATCH, WRAP).apply { topMargin = dp(4) })
        col.addView(i)

        // Generation progress line: 0 to 100 %
        val gl = TextView(this).apply { text = "Generation"; setTextColor(Ui.MUTED); textSize = 10f; typeface = Typeface.DEFAULT_BOLD }
        val gp = TextView(this).apply { text = "0%"; setTextColor(Ui.ACCENT); textSize = 11f; typeface = Typeface.DEFAULT_BOLD }
        genLabel = gl; genPctView = gp
        val gbar = GenBar(this)
        genBar = gbar
        val gHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(3), dp(4), dp(3), 0) }
        gHead.addView(gl, lpw(WRAP))
        gHead.addView(gp, lp(WRAP, WRAP))
        col.addView(gHead)
        col.addView(gbar, lp(MATCH, dp(16)))
        genBar?.setTarget(curPct); genLabel?.text = curGenText; genPctView?.text = "$curPct%"

        // Main actions
        val runThis = Pill(this, "${G.PLAY}  Run this", Ui.Kind.SECONDARY) { runOne() }
        holdTip(runThis) { "Ipadala ang kasalukuyang prompt lang: i-paste at pindutin ang arrow sa kanan-ibaba ng prompt box." }
        val runAllPill = Pill(this, "${G.PLAY_ALL}  Run all", Ui.Kind.PRIMARY) { if (running) stopAll("Stopped") else runAll() }
        runAllBtn = runAllPill
        holdTip(runAllPill) { "Ipadala lahat ng prompt isa-isa. Awtomatikong pipindutin ang arrow sa bawat isa, may paghihintay sa pagitan. Pindutin ulit para huminto." }
        val mainRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        mainRow.addView(runThis, lpw(dp(46)).apply { setMargins(dp(3), dp(8), dp(3), dp(3)) })
        mainRow.addView(runAllPill, lpw(dp(46)).apply { setMargins(dp(3), dp(8), dp(3), dp(3)) })
        col.addView(mainRow)

        // CONTROL
        val pause = tile(G.PAUSE, "Pause", { "I-pause o ituloy ang countdown habang tumatakbo ang Run all." }) { togglePause() }
        pauseTile = pause
        val back = tile(G.BACK, "Back", { "Bumalik sa nakaraang prompt." }) { index = maxOf(0, index - 1); refresh() }
        val skip = tile(G.SKIP, "Skip", { "Laktawan ang kasalukuyang prompt." }) { index++; refresh() }
        val restart = tile(G.RESTART, "Restart", { "Ibalik sa unang prompt." }) { index = 0; refresh() }
        col.addView(section("CONTROL"))
        col.addView(tileRow(pause, back, skip, restart))

        // LIST
        val paste = tile(G.PASTE, "Paste list", { "I-paste ang listahan ng prompts mula sa clipboard." }) { pasteClipboard() }
        val clear = tile(G.CLEAR, "Clear", { "Burahin lahat ng prompts sa kahon." }) { e.setText(""); index = 0; refresh() }
        val loop = tile(G.LOOP, "Loop", { "Uulit mula sa simula pagkatapos ng huling prompt." + onOff(flag("loop", false)) }) { t ->
            val v = !flag("loop", false); Prefs.setFlag(this, "loop", v); t.active = v
            toast("Loop" + onOff(v))
        }
        loop.active = flag("loop", false)
        val jitter = tile(G.RANDOM, "Random", { "Random na ±20% sa paghihintay para hindi laging pare-pareho ang oras." + onOff(flag("jitter", false)) }) { t ->
            val v = !flag("jitter", false); Prefs.setFlag(this, "jitter", v); t.active = v
            toast("Random wait" + onOff(v))
        }
        jitter.active = flag("jitter", false)
        col.addView(section("LIST"))
        col.addView(tileRow(paste, clear, loop, jitter))

        // PASTE INTERVAL
        val minus = Pill(this, G.MINUS, Ui.Kind.SECONDARY) { stepInterval(-1) }
        val plus = Pill(this, G.PLUS, Ui.Kind.SECONDARY) { stepInterval(1) }
        listOf(minus, plus).forEach { it.setPadding(0, 0, 0, 0); it.textSize = 18f }
        holdTip(minus) { "Paiklian ang paghihintay sa pagitan ng bawat paste." }
        holdTip(plus) { "Habaan ang paghihintay sa pagitan ng bawat paste. (Custom na segundo: Settings sa app.)" }
        val iv = TextView(this).apply {
            text = "${Prefs.delay(this@FloatingService)} s"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.ACCENT); gravity = Gravity.CENTER
        }
        intervalValue = iv
        val ivLabel = TextView(this).apply { text = "Paste interval"; setTextColor(Ui.TEXT); textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        val ivRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.stroked(Ui.SURFACE, Ui.LINE, dp(12).toFloat(), dp(1))
            setPadding(dp(10), dp(5), dp(6), dp(5))
        }
        ivRow.addView(ivLabel, lpw(WRAP))
        ivRow.addView(minus, lp(dp(38), dp(34)))
        ivRow.addView(iv, lp(dp(62), WRAP))
        ivRow.addView(plus, lp(dp(38), dp(34)))
        col.addView(section("TIMING"))
        col.addView(ivRow, lp(MATCH, WRAP).apply { setMargins(dp(3), 0, dp(3), 0) })

        // OPTIONS
        val glowT = tile(G.GLOW, "Glow", { "Rainbow glow ng bubble at panel. I-off para makatipid ng battery." + onOff(flag("glow", true)) }) { t ->
            val v = !flag("glow", true); Prefs.setFlag(this, "glow", v); t.active = v
            bubble?.glow = v; panelBorder?.glowOn = v
            toast("Glow" + onOff(v))
        }
        glowT.active = flag("glow", true)
        val autoHide = tile(G.HIDE, "Auto-hide", { "Kusang itatago ang panel kapag sinimulan ang Run all para hindi matakpan ang Flow." + onOff(flag("autohide", true)) }) { t ->
            val v = !flag("autohide", true); Prefs.setFlag(this, "autohide", v); t.active = v
            toast("Auto-hide" + onOff(v))
        }
        autoHide.active = flag("autohide", true)
        val alert = tile(G.BELL, "Done alert", { "May notification at tunog kapag umabot sa 100% ang generation." + onOff(flag("gensound", true)) }) { t ->
            val v = !flag("gensound", true); Prefs.setFlag(this, "gensound", v); t.active = v
            toast("Alert pag 100%" + onOff(v))
        }
        alert.active = flag("gensound", true)
        val help = tile(G.HELP, "Help", { "Pindutin para ipakita ang gabay. Pindutin ulit para itago." }) { _ ->
            helpPinned = !helpPinned
            if (helpPinned) showTip(
                "Hawakan ang kahit anong button para makita kung para saan ito.\n\n" +
                    "1. Buksan ang Google Flow\n2. I-paste o i-type ang prompts dito\n3. Pindutin ang Run this (isa) o Run all (lahat). Ang app na ang pipindot sa arrow.\n\n" +
                    "Gold na kulay = naka-on ang option."
            ) else { tipView?.visibility = View.GONE; panel?.post { positionPanel() } }
        }
        col.addView(section("OPTIONS"))
        col.addView(tileRow(glowT, autoHide, alert, help))

        // RECORD
        val rec = tile(G.REC, "Record", { "I-record ang screen (video lang). Lalabas ang pulang ■ box para huminto at ⏸ para mag-pause. Auto-save sa Gallery." }) { toggleRecord() }
        recTile = rec
        val fps = tile("${Prefs.fps(this)}", "FPS", { "Bilis ng screen record: 60 o 90 fps. Kapag hindi kaya ng phone ang 90, kusang bababa sa 60." }) { _ ->
            val next = if (Prefs.fps(this) >= 90) 60 else 90
            Prefs.setFps(this, next)
            refresh()
            toast("Screen record: $next fps")
        }
        fpsTile = fps
        val touch = tile(G.TOUCH, "Show touch", { "Ipakita ang bilog kung saan ka pumipindot sa video ng screen record." + onOff(flag("showtouch", false)) }) { t ->
            val v = !flag("showtouch", false)
            Prefs.setFlag(this, "showtouch", v); t.active = v
            toast("Show touch" + onOff(v))
            if (v && checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Walang permission: i-on mo muna ang 'Show taps' sa Developer options (o tingnan ang README para sa auto).", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
        }
        touch.active = flag("showtouch", false)
        val close = tile(G.CLOSE, "Close", { "Isara ang FLOW at alisin ang bubble." }, danger = true) { stopSelf() }
        col.addView(section("RECORD"))
        col.addView(tileRow(rec, fps, touch, close))

        val sv = MaxHeightScrollView(this, (resources.displayMetrics.heightPixels * 0.78f).toInt()).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        sv.addView(col, frameLp())
        root.addView(sv, lp(MATCH, WRAP))
        return root
    }

    private fun frameLp() = android.widget.FrameLayout.LayoutParams(
        android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
    )

    private fun stepInterval(dir: Int) {
        val cur = Prefs.delay(this)
        val p = DELAY_PRESETS
        val next = if (dir > 0) (p.firstOrNull { it > cur } ?: p.last()) else (p.lastOrNull { it < cur } ?: p.first())
        Prefs.setDelay(this, next)
        intervalValue?.text = "$next s"
    }

    // ── State on screen ────────────────────────────────────────────────────

    private fun list(): List<String> =
        parsePrompts(edit?.text?.toString() ?: Prefs.prompts(this, shownKind))

    private fun refresh() {
        val l = list()
        if (index >= l.size) index = 0
        info?.text = when {
            l.isEmpty() -> "No prompts yet"
            running && paused -> "Paused at ${index + 1} / ${l.size}"
            running && remaining > 0 -> "Running ${index + 1} / ${l.size}  ·  next in ${remaining}s"
            running -> "Running ${index + 1} / ${l.size}…"
            else -> "${kindIcon(shownKind)} Next: ${index + 1} / ${l.size}  ·  " + l[index].take(34) + if (l[index].length > 34) "…" else ""
        }
        runAllBtn?.let {
            if (running) { it.text = "${G.STOP}  Stop"; it.setKind(Ui.Kind.DANGER) }
            else { it.text = "${G.PLAY_ALL}  Run all"; it.setKind(Ui.Kind.PRIMARY) }
        }
        recTile?.let {
            val on = RecordService.recording
            it.setGlyph(if (on) G.STOP else G.REC)
            it.setLabel(if (on) "Stop rec" else "Record")
            it.danger = true
            it.active = false
        }
        fpsTile?.setGlyph("${Prefs.fps(this)}")
        pauseTile?.let {
            it.setGlyph(if (paused) G.PLAY else G.PAUSE)
            it.setLabel(if (paused) "Resume" else "Pause")
            it.active = paused
        }
        intervalValue?.text = "${Prefs.delay(this)} s"
        updateBubble()
    }

    private fun toggleRecord() {
        if (RecordService.recording) {
            startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
            return
        }
        // Keep the panel out of the video; Android then shows its own "start recording?" dialog.
        if (panelOpen && !panelBusy) hidePanel()
        startActivity(Intent(this, RecordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun togglePause() {
        if (!running) { toast("Walang tumatakbo"); return }
        paused = !paused
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pasteClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) { toast("Clipboard is empty. Copy your prompts in Prompt Shots first."); return }
        edit?.setText(t); index = 0; refresh()
    }

    // ── Generation progress (0 → 100 %) ────────────────────────────────────

    private fun setGen(pct: Int, text: String) {
        curPct = pct; curGenText = text
        genBar?.setTarget(pct)
        genLabel?.text = text
        genPctView?.text = "$pct%"
        bubble?.progress = pct / 100f
    }

    /** Start watching Flow's tiles after a prompt was sent. */
    private fun armGen() {
        genSeen = false; genMissing = 0
        genStart = SystemClock.elapsedRealtime()
        genChat = shownKind == PromptKind.CHATGPT
        setGen(0, if (genChat) "Waiting for ChatGPT…" else "Waiting for Flow…")
        if (!genArmed) {
            genArmed = true
            ui.postDelayed(genTick, 1500)
        }
    }

    private val genTick = object : Runnable {
        override fun run() {
            if (!genArmed) return
            val svc = FlowAccessibilityService.instance
            if (genChat) {
                // ChatGPT shows no percent: ease the line toward 90 % while it is busy, jump to 100 % when it stops.
                val now = SystemClock.elapsedRealtime()
                if (svc != null && svc.chatGptBusy()) {
                    genSeen = true; genMissing = 0
                    val t = (now - genStart) / 1000.0
                    setGen((90 * (1 - exp(-t / 40.0))).toInt(), "Generating")
                } else if (genSeen) {
                    if (svc != null && svc.promptBoxVisible()) genMissing++
                    if (genMissing >= 3) { completeGen(); return }
                } else if (now - genStart > 30_000L) {
                    genArmed = false
                    setGen(0, "Idle")
                    return
                }
                ui.postDelayed(this, 1000)
                return
            }
            val p = svc?.readProgress()
            when {
                p != null -> {
                    genSeen = true; genMissing = 0
                    setGen(p, "Generating")
                    if (p >= 100) { completeGen(); return }
                }
                genSeen -> {
                    // The % text vanished. Only count it when Flow is on screen, so leaving the app doesn't fake a finish.
                    if (svc != null && svc.promptBoxVisible()) genMissing++
                    if (genMissing >= 3) { completeGen(); return }
                }
                SystemClock.elapsedRealtime() - genStart > 15 * 60_000L -> {
                    genArmed = false
                    setGen(0, "Idle")
                    return
                }
            }
            ui.postDelayed(this, 800)
        }
    }

    private fun completeGen() {
        genArmed = false
        setGen(100, "Complete")
        if (flag("gensound", true)) Notifier.done(this, "Generation complete", if (genChat) "ChatGPT finished." else "Flow reached 100%.")
        ui.postDelayed({ if (!genArmed) setGen(0, "Idle") }, 3000)
    }

    // ── Running ────────────────────────────────────────────────────────────

    /** ChatGPT can't take a new prompt while it is still answering, so wait (up to 4 min) until it is idle. */
    private fun whenReady(stillWanted: () -> Boolean, block: () -> Unit) {
        val svc = FlowAccessibilityService.instance
        if (shownKind != PromptKind.CHATGPT || svc == null || !svc.chatGptBusy()) { block(); return }
        val start = SystemClock.elapsedRealtime()
        val r = object : Runnable {
            override fun run() {
                if (!stillWanted()) return
                if (!svc.chatGptBusy() || SystemClock.elapsedRealtime() - start > 4 * 60_000L) { block(); return }
                h.postDelayed(this, 1000)
            }
        }
        h.postDelayed(r, 1000)
    }

    private fun runOne() {
        if (running) { toast("Run all is active. Stop it first."); return }
        if (sending) return
        if (selected == 0) applyAuto()
        val l = list()
        if (l.isEmpty()) { toast("Add prompts first"); return }
        if (index >= l.size) index = 0
        val svc = FlowAccessibilityService.instance
        if (svc == null) { toast("Turn on Accessibility in Prompt Shots > Setup"); return }
        sending = true
        whenReady({ true }) {
            svc.pasteAndRun(l[index]) { ok, msg ->
                sending = false
                toast(msg)
                if (ok) { index++; refresh(); armGen() } // a failed prompt stays selected so you can retry it
            }
        }
    }

    private fun runAll() {
        if (running) return
        if (selected == 0) applyAuto()
        if (list().isEmpty()) { toast("Add prompts first"); return }
        if (FlowAccessibilityService.instance == null) { toast("Turn on Accessibility in Prompt Shots > Setup"); return }
        running = true
        remaining = 0
        refresh()
        // Get the panel out of the way so it doesn't cover Flow while it works.
        if (panelOpen && !panelBusy && flag("autohide", true)) hidePanel()
        step()
    }

    private fun stopAll(msg: String? = null) {
        running = false
        paused = false
        sending = false
        remaining = 0
        h.removeCallbacksAndMessages(null)
        refresh()
        if (msg != null) toast(msg)
    }

    /** Ends Run all and tells the user with a notification only (no toast). */
    private fun finish(title: String, text: String) {
        stopAll()
        Notifier.done(this, title, text)
    }

    /** Sends the current prompt. On success, counts down the wait, then goes again. */
    private fun step() {
        if (!running) return
        val l = list()
        val svc = FlowAccessibilityService.instance
        if (svc == null) { finish("Automation stopped", "Accessibility turned off."); return }
        if (index >= l.size) { index = 0; finish("Automation finished", "All prompts were sent."); return }
        sending = true
        whenReady({ running }) {
            svc.pasteAndRun(l[index]) { ok, msg ->
                sending = false
                if (!running) return@pasteAndRun
                if (!ok) { finish("Automation stopped", "Stopped at prompt ${index + 1}: $msg"); return@pasteAndRun }
                armGen()
                index++
                if (index >= l.size) {
                    if (flag("loop", false)) index = 0
                    else { index = 0; finish("Automation finished", "All prompts were sent."); return@pasteAndRun }
                }
                val base = Prefs.delay(this)
                remaining = if (flag("jitter", false)) (base * (0.8 + Math.random() * 0.4)).toInt().coerceAtLeast(3) else base
                refresh()
                h.postDelayed(tick, 1000)
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (paused) { h.postDelayed(this, 500); return }
            remaining--
            if (remaining <= 0) { remaining = 0; refresh(); step() }
            else { refresh(); h.postDelayed(this, 1000) }
        }
    }
}
