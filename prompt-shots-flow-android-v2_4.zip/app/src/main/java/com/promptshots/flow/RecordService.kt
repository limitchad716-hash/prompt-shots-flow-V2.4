package com.promptshots.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/**
 * Records the screen to an .mp4 (video only) using MediaProjection.
 * While recording it shows a small floating control: red stop box, pause/resume and a timer.
 * Stopping saves the video straight to the gallery (Movies/PromptShots).
 */
class RecordService : Service() {
    companion object {
        @Volatile var recording = false
        @Volatile var paused = false
        /** Set by FloatingService so its button/bubble update when recording starts or stops. */
        @Volatile var onChange: (() -> Unit)? = null
        const val ACTION_STOP = "com.promptshots.flow.RECORD_STOP"
        const val ACTION_PAUSE = "com.promptshots.flow.RECORD_PAUSE"
        private const val NOTIF_ID = 2
        private const val TOUCH_KEY = "show_touches"
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var file: File? = null
    private var active = false
    private var usedFps = 0
    private val main = Handler(Looper.getMainLooper())

    // Show-touch handling (needs WRITE_SECURE_SETTINGS, granted once through adb)
    private var touchChanged = false
    private var touchBefore = 0

    // Floating control + timer
    private var wm: WindowManager? = null
    private var ctrl: LinearLayout? = null
    private var timerView: TextView? = null
    private var pauseBtn: TextView? = null
    private var accMs = 0L
    private var segStart = 0L

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_STOP -> { finish(); return START_NOT_STICKY }
            ACTION_PAUSE -> { togglePause(); return START_NOT_STICKY }
        }
        startForegroundNow() // must happen right after startForegroundService()
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = i?.getParcelableExtra<Intent>("data")
        if (active || data == null) { if (!active) stopSelf(); return START_NOT_STICKY }
        try {
            begin(code, data)
        } catch (e: Exception) {
            toast("Hindi masimulan ang screen record")
            releaseOutput(deleteOutput = true)
            stopProjection()
            restoreTouches()
            recording = false
            onChange?.invoke()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (active) finish()
        super.onDestroy()
    }

    // ── Notification ───────────────────────────────────────────────────────

    private fun action(code: Int, label: String, icon: Int, act: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, RecordService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("rec", "Screen recording", NotificationManager.IMPORTANCE_LOW))
        }
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "rec") else Notification.Builder(this)
        return b.setContentTitle(if (paused) "Naka-pause ang screen record" else "Nagre-record ang screen")
            .setContentText("Pindutin ang Stop para i-save sa gallery")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .addAction(
                if (paused) action(3, "Resume", android.R.drawable.ic_media_play, ACTION_PAUSE)
                else action(3, "Pause", android.R.drawable.ic_media_pause, ACTION_PAUSE)
            )
            .addAction(action(4, "Stop", android.R.drawable.ic_menu_close_clear_cancel, ACTION_STOP))
            .build()
    }

    private fun startForegroundNow() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIF_ID, n)
    }

    // ── Start ──────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun begin(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        // Android 14+ requires a callback to be registered before creating the virtual display.
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { finish() } }
        }, main)
        projection = mp

        val real = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(real)
        // At most 1080 px on the short side, even numbers only.
        val scale = min(1f, 1080f / min(real.widthPixels, real.heightPixels))
        val w = (real.widthPixels * scale).toInt() and 1.inv()
        val h = (real.heightPixels * scale).toInt() and 1.inv()

        // Try the fps chosen in the panel (60 or 90); if this phone's encoder refuses, step down.
        val want = Prefs.fps(this)
        val chain = if (want >= 90) intArrayOf(90, 60, 30) else intArrayOf(60, 30)
        var failure: Exception? = null
        usedFps = 0
        for (fps in chain) {
            try {
                startRecorder(mp, w, h, real.densityDpi, fps)
                failure = null
                usedFps = fps
                break
            } catch (e: Exception) {
                failure = e
                releaseOutput(deleteOutput = true)
            }
        }
        failure?.let { throw it }

        enableTouches()
        active = true
        recording = true
        paused = false
        accMs = 0L
        segStart = SystemClock.elapsedRealtime()
        showControl()
        onChange?.invoke()
        toast("Nagsimula ang screen record  ·  $usedFps fps" + if (usedFps < want) "  (hindi kaya ng phone ang $want)" else "")
    }

    private fun startRecorder(mp: MediaProjection, w: Int, h: Int, dpi: Int, fps: Int) {
        val name = "PromptShots_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        recorder = rec
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        rec.setVideoEncodingBitRate(if (fps >= 90) 24_000_000 else if (fps >= 60) 16_000_000 else 10_000_000)
        rec.setVideoFrameRate(fps)
        rec.setVideoSize(w, h)
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PromptShots")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("no uri")
            uri = u
            val p = contentResolver.openFileDescriptor(u, "w") ?: throw IllegalStateException("no fd")
            pfd = p
            rec.setOutputFile(p.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: throw IllegalStateException("no dir")
            dir.mkdirs()
            val f = File(dir, name)
            file = f
            rec.setOutputFile(f.absolutePath)
        }
        rec.prepare()
        display = mp.createVirtualDisplay(
            "PromptShotsRec", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
        )
        rec.start()
    }

    // ── Pause / stop ───────────────────────────────────────────────────────

    private fun togglePause() {
        if (!active) return
        try {
            if (paused) recorder?.resume() else recorder?.pause()
        } catch (_: Exception) {
            toast("Hindi ma-pause ang record sa phone na ito")
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (paused) segStart = now else accMs += now - segStart
        paused = !paused
        pauseBtn?.text = if (paused) "▶" else "⏸"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        onChange?.invoke()
    }

    /** Stops, saves to the gallery and closes everything. Safe to call more than once. */
    private fun finish() {
        if (!active) { stopSelf(); return }
        active = false
        recording = false
        paused = false
        main.removeCallbacks(tick)
        hideControl()
        var ok = true
        try { recorder?.stop() } catch (_: Exception) { ok = false } // throws if stopped too quickly
        val path = file?.absolutePath
        releaseOutput(deleteOutput = !ok)
        stopProjection()
        restoreTouches()
        if (ok) {
            if (path != null) MediaScannerConnection.scanFile(this, arrayOf(path), arrayOf("video/mp4"), null)
            toast(if (Build.VERSION.SDK_INT >= 29) "Na-save na sa Gallery (Movies/PromptShots)" else "Na-save ang video (Movies sa app folder)")
        } else {
            toast("Masyadong maikli ang record, hindi na-save")
        }
        onChange?.invoke()
        stopForeground(true)
        stopSelf()
    }

    private fun releaseOutput(deleteOutput: Boolean) {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        uri?.let {
            try {
                if (deleteOutput) contentResolver.delete(it, null, null)
                else if (Build.VERSION.SDK_INT >= 29) {
                    // Clearing "pending" is what makes the video appear in the gallery.
                    contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                } else {
                    // nothing to do on older Android versions
                }
            } catch (_: Exception) {}
        }
        uri = null
        if (deleteOutput) try { file?.delete() } catch (_: Exception) {}
        file = null
    }

    private fun stopProjection() {
        val mp = projection
        projection = null // so the stop callback doesn't re-enter finish()
        try { mp?.stop() } catch (_: Exception) {}
    }

    // ── Show touches (system setting) ──────────────────────────────────────

    private fun enableTouches() {
        if (!Prefs.flag(this, "showtouch", false)) return
        try {
            touchBefore = Settings.System.getInt(contentResolver, TOUCH_KEY, 0)
            if (touchBefore == 0) {
                Settings.System.putInt(contentResolver, TOUCH_KEY, 1)
                touchChanged = true
            }
        } catch (_: Exception) {
            toast("Walang pahintulot para sa Show touch. Tingnan ang README.")
        }
    }

    private fun restoreTouches() {
        if (!touchChanged) return
        touchChanged = false
        try { Settings.System.putInt(contentResolver, TOUCH_KEY, touchBefore) } catch (_: Exception) {}
    }

    // ── Floating control: [red stop box] [pause] [timer] ───────────────────

    private fun elapsed(): Long =
        accMs + if (paused) 0L else SystemClock.elapsedRealtime() - segStart

    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            val s = elapsed() / 1000
            timerView?.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            main.postDelayed(this, 500)
        }
    }

    private fun showControl() {
        if (!Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w

        val stop = TextView(this).apply {
            text = "■"; textSize = 18f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply { setColor(0xFFE53935.toInt()); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0x88FFFFFF.toInt()) }
            setOnClickListener { finish() }
        }
        val pause = TextView(this).apply {
            text = "⏸"; textSize = 18f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF1C2030.toInt()); setStroke(dp(1), 0xFF2B3045.toInt()) }
            setOnClickListener { togglePause() }
        }
        pauseBtn = pause
        val timer = TextView(this).apply {
            text = "00:00"; textSize = 14f; gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), 0, dp(6), 0)
        }
        timerView = timer
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply { setColor(0xEB07080D.toInt()); cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0xFFF5C451.toInt()) }
        }
        box.addView(stop, LinearLayout.LayoutParams(dp(44), dp(44)))
        box.addView(pause, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })
        box.addView(timer)

        val type = overlayType()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12); lp.y = dp(90)

        // Drag by the timer / padding; the two buttons keep their own taps.
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - tx) > 4 || abs(e.rawY - ty) > 4) {
                            lp.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - v.width))
                            lp.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - v.height))
                            try { w.updateViewLayout(v, lp) } catch (_: Exception) {}
                        }
                    }
                }
                return true
            }
        })
        try { w.addView(box, lp); ctrl = box } catch (_: Exception) {}
        main.post(tick)
    }

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun hideControl() {
        ctrl?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        ctrl = null; timerView = null; pauseBtn = null
    }

    private fun toast(s: String) = main.post { Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show() }
}
