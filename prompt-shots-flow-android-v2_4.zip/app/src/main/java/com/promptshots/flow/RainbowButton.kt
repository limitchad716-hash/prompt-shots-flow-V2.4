package com.promptshots.flow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.TextView

/**
 * Big home-screen button: rotating rainbow edge with a strong rainbow glow.
 * The glow is stacked translucent strokes (no software blur layer), so it animates smoothly on the GPU.
 */
class RainbowButton(c: Context, label: String, sub: String, private val onTap: () -> Unit) : TextView(c) {
    private val inset = Ui.dp(c, 26).toFloat()
    private val radius = Ui.dp(c, 22).toFloat()
    private val stroke = Ui.dp(c, 3).toFloat()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.SURFACE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val haloExtra = floatArrayOf(4f, 10f, 18f, 27f, 36f)
    private val haloAlpha = intArrayOf(190, 130, 84, 46, 20)
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var anim: ValueAnimator? = null
    private var last = 0L
    private var danger = false

    init {
        setLabel(label, sub)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Ui.TEXT)
        isClickable = true
        setOnClickListener {
            val now = SystemClock.uptimeMillis()
            if (now - last >= 350) { last = now; onTap() }
        }
    }

    fun setLabel(label: String, sub: String) {
        val s = SpannableString(label + "\n" + sub)
        s.setSpan(RelativeSizeSpan(0.5f), label.length, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(ForegroundColorSpan(Ui.MUTED), label.length, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        text = s
        textSize = 24f
    }

    fun setDanger(on: Boolean) {
        if (danger == on) return
        danger = on
        setTextColor(if (on) Ui.BAD else Ui.TEXT)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        shader = SweepGradient(w / 2f, h / 2f, Ui.RAINBOW, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (anim == null) {
            anim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 4500
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { angle = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(90).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(DecelerateInterpolator()).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(canvas: Canvas) {
        val sh = shader
        if (sh != null) {
            matrix.setRotate(angle, width / 2f, height / 2f)
            sh.setLocalMatrix(matrix)
            ring.shader = sh
            halo.shader = sh
        }
        rect.set(inset, inset, width - inset, height - inset)
        for (i in haloExtra.indices) {
            halo.strokeWidth = stroke + haloExtra[i]
            halo.alpha = haloAlpha[i]
            canvas.drawRoundRect(rect, radius, radius, halo)
        }
        fill.color = if (isPressed) Ui.SURFACE_HI else Ui.SURFACE
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, ring)
        super.onDraw(canvas)
    }
}
