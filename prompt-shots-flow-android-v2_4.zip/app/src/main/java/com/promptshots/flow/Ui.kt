package com.promptshots.flow

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout

/** Shared premium look (obsidian + gold, rainbow glow) so the app and the floating window match. */
object Ui {
    val BG = 0xFF07080D.toInt()
    val BG2 = 0xFF111426.toInt()
    val SURFACE = 0xFF121521.toInt()
    val SURFACE_HI = 0xFF1C2030.toInt()
    val LINE = 0xFF2B3045.toInt()
    val ACCENT = 0xFFF5C451.toInt()
    val ACCENT_DEEP = 0xFFC98A1B.toInt()
    val ON_ACCENT = 0xFF1A1100.toInt()
    val TEXT = 0xFFF3F5FB.toInt()
    val MUTED = 0xFF8D95AA.toInt()
    val OK = 0xFF3DDC84.toInt()
    val OK_BG = 0xFF11261B.toInt()
    val BAD = 0xFFFF6B6B.toInt()
    val BAD_BG = 0xFF2B1418.toInt()

    /** Same rainbow as before: it is the glow colour everywhere. */
    val RAINBOW = intArrayOf(
        0xFFFF3B3B.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF3DDC84.toInt(),
        0xFF29C5F6.toInt(), 0xFF5C6BFF.toInt(), 0xFFD84BFF.toInt(), 0xFFFF3B3B.toInt()
    )

    enum class Kind { PRIMARY, SECONDARY, DANGER }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    fun stroked(color: Int, line: Int, radius: Float, lineWidth: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(lineWidth, line)
    }

    fun gold(radius: Float) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(ACCENT, ACCENT_DEEP)
    ).apply { cornerRadius = radius }

    /** Equal-width row with a small gap between the children. */
    fun row(c: Context, vararg v: View): LinearLayout {
        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val m = dp(c, 3)
        v.forEach {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(m, m, m, m)
            r.addView(it, lp)
        }
        return r
    }
}
