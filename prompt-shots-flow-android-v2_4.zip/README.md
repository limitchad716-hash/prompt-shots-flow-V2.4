# Prompt Shots + FLOW floating window (v2.4)

**Build:** upload this project to GitHub, open Actions > Build APK > Run workflow, then download the APK artifact.

## v2.4 changes
- **ChatGPT mode** (tile **💬 GPT**, also picked automatically when the front app/page says ChatGPT). Works with the ChatGPT app and with chatgpt.com in a browser: you log in as usual, the panel pastes into the message box and presses send. It has its own prompt list.
- **Waits for ChatGPT.** Before each next prompt it waits (up to 4 min) until ChatGPT's Stop button is gone, and it never taps Stop by mistake.
- **Progress for ChatGPT.** ChatGPT shows no percent, so the line eases toward 90 % while it is busy and jumps to 100 % when it finishes; then the notification + sound plays.
- **Lighter on the GPU.** The bubble glow stays on but stops rotating while Run all is working.

## v2.3 changes
- **No more duplicate windows.** Tapping the bubble (or any button) many times can no longer open two panels. The panel ignores taps while it pops in/out, every button has a short tap guard, and the Float button on the home screen can't start the service twice. The app opens as a single task (no extra copies in Recents).
- **Clear, labelled buttons.** Every option is now a tile with a symbol and a name (Pause, Back, Skip, Restart, Paste list, Clear, Loop, Random, Glow, Auto-hide, Done alert, Help, Record, FPS, Show touch, Close). Big **Run this** and **Run all** buttons on top. Hold any button to see what it does.
- **Automatic send arrow.** After pasting each prompt the app presses the arrow at the bottom right of Flow's prompt box, then does the same for every next prompt. It tries (1) the button's label, (2) the right-most small button inside the prompt card, (3) a real finger tap on that button. It keeps trying for about 4 seconds because the arrow only turns on after the text lands.
- **Paste interval.** New **Paste interval  − 60 s +** control in the panel (5 s to 10 min in steps). Settings > Paste interval accepts any value from 5 to 3600 s. Random wait still adds +/-20 %.
- **Screen record 60 or 90 fps.** Tap the **FPS** tile (or Settings > Screen record). 90 fps steps down to 60, then 30, if the phone's encoder or screen can't do it, and the toast tells you the real fps that was used.
- **Generation progress line (0 to 100 %).** A neon line in the panel and a progress ring on the bubble follow the "NN%" text Flow shows on a tile while it generates. When it reaches 100 % (or the percent text disappears while Flow is on screen) you get a notification with sound: your uploaded sound from Settings > Notification sound, or the default one. Toggle it with the **Done alert** tile.
- **Smoother animation.** Glows are drawn on the GPU (no software blur layer), buttons use one short press animation, and old animations are cancelled before new ones start.
- **Premium look.** New F logo icon (adaptive icon + round icon), obsidian and gold theme, much stronger rainbow glow (same colours) on the bubble, the panel border and the home buttons. Glow tile turns it all off to save battery.

## v2.2 changes
- Main screen now shows only **Float** and **Settings**, each with a rotating rainbow edge and glow.
- When Run all finishes (or stops on an error) the floating window only sends a **notification**, no toast.
- **Settings > Notification sound**: Upload a sound, Play to preview, then **Save**. That sound plays when automation finishes. "Use default sound" resets it.

## How to use
1. Open the app, tap the red chips (or **Setup**) and turn on: floating window, accessibility, notifications.
2. Tap **Float**. A round FLOW bubble appears over other apps.
3. Open Google Flow, tap the bubble, paste your prompts (one per line, or separated by blank lines).
4. **Run this** sends one prompt. **Run all** sends them one by one with the wait time from Setup.

## Image / Video / Auto
The panel has three buttons: **Auto**, **Image**, **Video**. Image and Video each keep their own prompt list.
In **Auto**, the app reads the Flow screen (model chip such as Nano Banana / Imagen = image, Veo = video) and switches to the matching list. The panel shows what it detected. Detection is keyword based, so if it guesses wrong, just tap Image or Video.

## Floating panel (hold any button to see what it does)
- Top: **Auto / Image / Video**, the prompt box, the generation line (0 to 100 %), then **Run this** and **Run all / Stop**.
- **CONTROL:** Pause, Back, Skip, Restart. **LIST:** Paste list, Clear, Loop, Random.
- **TIMING:** Paste interval with − and +. **OPTIONS:** Glow, Auto-hide, Done alert, Help.
- **RECORD:** Record, FPS (60 / 90), Show touch, Close.
- Recording is video only. While recording a small control appears: red **■** box (stop + save to Gallery), **⏸** pause/resume and a timer. Drag it by the timer. The notification has Pause and Stop too.
- Videos go to Movies/PromptShots (Android 10+, shows in Gallery right away).
- **Show touch** draws a circle where you tap. Android only lets an app change this setting after a one-time grant from a computer:
  `adb shell pm grant com.promptshots.flow android.permission.WRITE_SECURE_SETTINGS`
  Without it, turn on *Settings > Developer options > Show taps* by hand.
- Gold tile = option is on.

## What's new in 2.1
- Cleaner UI: status chips (tap to fix), progress bar, offline screen with Try again.
- Panel pops in/out with an animation and has a rotating rainbow border. Bubble and border follow the screen refresh rate (60 fps or higher).
- Bubble has a rotating rainbow glow and shows a live countdown (green) while Run all is running; snaps to screen edges.
- Run all **stops** if the prompt box or Generate button can't be found, instead of silently skipping prompts. The failed prompt stays selected.
- Generate detection retries a few times and only matches short, whole-word labels.
- Prompts auto-save as you type; blank-line separated multi-line prompts supported.
- Panel stays on screen; hides itself when Run all starts.
- Notification has a Close action; Float button toggles to Stop float.
